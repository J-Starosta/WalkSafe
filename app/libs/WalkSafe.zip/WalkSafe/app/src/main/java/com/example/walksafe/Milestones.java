package com.example.walksafe;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Milestones extends AppCompatActivity {

    FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    DatabaseReference mDatabaseReference = firebaseDatabase.getReference("Users");
    String userID;
    Integer progress1, progress2, progress3, milestone_1, milestone_2, milestone_3, points;
    private Object Tag;
    int numberOfDiscounts;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_milestones);

        userID = getIntent().getStringExtra("EXTRA_USER_ID");



        //Setting display
       mDatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot snapshot : dataSnapshot.getChildren()){
                    String key = snapshot.getKey();
                    Log.d((String) Tag, "Snapshot value: " + snapshot);
                    Log.d((String) Tag, "Key value: " + key);
                    if(key.equals(userID)) {

                        /*############## Initialization of variables ##############*/

                        int tableMilestones[][] = {
                                {0, 100, 250, 500, 800, 1500},
                                {0, 10, 21, 62, 124, 200},
                                {0, 10, 50, 120, 180, 250}
                        };
                        //Text view
                        TextView PointsTextView = (TextView) findViewById(R.id.PointsTextView);
                        TextView Milestone1TextView = (TextView) findViewById(R.id.Milestone1TextView);
                        TextView Milestone2TextView = (TextView) findViewById(R.id.Milestone2TextView);
                        TextView Milestone3TextView = (TextView) findViewById(R.id.Milestone3TextView);
                        TextView ProgressBarTextView1 = (TextView) findViewById(R.id.ProgressBarTextView1);
                        TextView ProgressBarTextView2 = (TextView) findViewById(R.id.ProgressBarTextView2);
                        TextView ProgressBarTextView3 = (TextView) findViewById(R.id.ProgressBarTextView3);

                        //Progress bars
                        ProgressBar Milestone1ProgressBar = (ProgressBar) findViewById(R.id.Milestone1ProgressBar);
                        ProgressBar Milestone2ProgressBar = (ProgressBar) findViewById(R.id.Milestone2ProgressBar);
                        ProgressBar Milestone3ProgressBar = (ProgressBar) findViewById(R.id.Milestone3ProgressBar);

                        /*############## Getting values from Firebase ##############*/

                        milestone_1 = Integer.valueOf(String.valueOf(snapshot.child("Milestone_1").getValue()));
                        Log.d(String.valueOf((Integer) Tag), "Milestone_1 value:" + milestone_1);
                        milestone_2 = Integer.valueOf(String.valueOf(snapshot.child("Milestone_2").getValue()));
                        Log.d(String.valueOf((Integer) Tag), "Milestone_2 value:" + milestone_2);
                        milestone_3 = Integer.valueOf(String.valueOf(snapshot.child("Milestone_3").getValue()));
                        Log.d(String.valueOf((Integer) Tag), "Milestone_3 value:" + milestone_3);
                        points = Integer.valueOf(String.valueOf(snapshot.child("Points").getValue()));
                        Log.d(String.valueOf((Integer) Tag), "Points value:" + points);

                        /*############## Setting the range on progress bars ##############*/

                        for(int j = 0; j < 3; j++){
                            for(int i = 1; i < 6; i++){
                                if(j == 0) {
                                    if(milestone_1 < tableMilestones[j][i] && milestone_1 > tableMilestones[j][i-1]){
                                        Milestone1ProgressBar.setMax(tableMilestones[j][i]);
                                        ProgressBarTextView1.setText(milestone_1 + "/" + Milestone1ProgressBar.getMax());
                                    }
                                    else if(milestone_1 == tableMilestones[j][i] && milestone_1 < tableMilestones[j][4]){
                                        Milestone1ProgressBar.setMax(tableMilestones[j][i+1]);
                                        ProgressBarTextView1.setText(milestone_1 + "/" + Milestone1ProgressBar.getMax());
                                    }
                                    else if (milestone_1 >= tableMilestones[j][4]){
                                        Milestone1ProgressBar.setMax(tableMilestones[j][4]);
                                        milestone_1 = tableMilestones[j][4];
                                        ProgressBarTextView1.setText("Achievement completed");
                                    }
                                    else if(milestone_1 == 0){
                                        Milestone1ProgressBar.setMax(tableMilestones[j][1]);
                                        ProgressBarTextView1.setText(milestone_1 + "/" + Milestone1ProgressBar.getMax());
                                    }
                                }
                                else if(j == 1) {
                                    if(milestone_2 < tableMilestones[j][i] && milestone_2 > tableMilestones[j][i-1]) {
                                        Milestone2ProgressBar.setMax(tableMilestones[j][i]);
                                        ProgressBarTextView2.setText(milestone_2 + "/" + Milestone2ProgressBar.getMax());
                                    }
                                    else if(milestone_2 == tableMilestones[j][i] && milestone_2 < tableMilestones[j][4]){
                                        Milestone2ProgressBar.setMax(tableMilestones[j][i+1]);
                                        ProgressBarTextView2.setText(milestone_2 + "/" + Milestone2ProgressBar.getMax());
                                    }
                                    else if (milestone_2 >= tableMilestones[j][4]){
                                        Milestone2ProgressBar.setMax(tableMilestones[j][4]);
                                        milestone_2 = tableMilestones[j][4];
                                        ProgressBarTextView2.setText("Achievement completed");
                                    }
                                    else if( milestone_2 == 0){
                                        Milestone2ProgressBar.setMax(tableMilestones[j][1]);
                                        ProgressBarTextView2.setText(milestone_2 + "/" + Milestone2ProgressBar.getMax());
                                    }
                                }
                                else if(j == 2) {
                                    if(milestone_3 < tableMilestones[j][i] && milestone_3 > tableMilestones[j][i-1]) {
                                        Milestone3ProgressBar.setMax(tableMilestones[j][i]);
                                        ProgressBarTextView3.setText(milestone_3 + "/" + Milestone3ProgressBar.getMax());
                                    }
                                    else if(milestone_3 == tableMilestones[j][i] && milestone_3 < tableMilestones[j][4]){
                                        Milestone3ProgressBar.setMax(tableMilestones[j][i+1]);
                                        ProgressBarTextView3.setText(milestone_3 + "/" + Milestone3ProgressBar.getMax());
                                    }
                                    else if (milestone_3 >= tableMilestones[j][4]){
                                        Milestone3ProgressBar.setMax(tableMilestones[j][4]);
                                        milestone_3 = tableMilestones[j][4];
                                        ProgressBarTextView3.setText("Achievement completed");
                                    }
                                    else if(milestone_3 == 0) {
                                        Milestone3ProgressBar.setMax(tableMilestones[j][1]);
                                        ProgressBarTextView3.setText(milestone_3 + "/" + Milestone3ProgressBar.getMax());
                                    }
                                }
                            }
                        }

                        /*############## Setting data for progress bars ##############*/

                        Milestone1ProgressBar.setProgress(milestone_1);
                        Milestone2ProgressBar.setProgress(milestone_2);
                        Milestone3ProgressBar.setProgress(milestone_3);

                        Milestone1TextView.setText("Cross the road "  + Milestone1ProgressBar.getMax()+" times.");
                        Milestone2TextView.setText(Milestone2ProgressBar.getMax() + " days in a row.");
                        Milestone3TextView.setText("Use " + Milestone3ProgressBar.getMax() + " different crossings.");

                        numberOfDiscounts = (int) points/100;
                        PointsTextView.setText("Number of discounts: " + numberOfDiscounts);
                    }
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
        }
    }

